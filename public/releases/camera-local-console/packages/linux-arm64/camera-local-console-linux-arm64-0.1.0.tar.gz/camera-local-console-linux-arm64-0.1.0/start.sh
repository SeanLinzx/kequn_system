#!/bin/bash
cd "$(dirname "$0")"
exec node src/server.js
