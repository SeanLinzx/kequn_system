fake binary
